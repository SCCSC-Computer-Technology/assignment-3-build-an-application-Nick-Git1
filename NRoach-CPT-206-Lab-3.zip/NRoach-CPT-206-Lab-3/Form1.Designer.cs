﻿namespace NRoach_CPT_206_Lab_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.stateDBGridView = new System.Windows.Forms.DataGridView();
            this.stateIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stateNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.populationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flagDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stateFlowerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stateBirdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colorsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.largestCitiesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stateCapitalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medianIncomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.computerJobPercentageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stateDBDataSet = new NRoach_CPT_206_Lab_3.StateDBDataSet();
            this.stateDB = new NRoach_CPT_206_Lab_3.StateDB();
            this.stateDBBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.statesTableAdapter = new NRoach_CPT_206_Lab_3.StateDBDataSetTableAdapters.StatesTableAdapter();
            this.comboBoxStates = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.seeInfoBtn = new System.Windows.Forms.Button();
            this.stateDataDataSet1 = new NRoach_CPT_206_Lab_3.StateDataDataSet();
            ((System.ComponentModel.ISupportInitialize)(this.stateDBGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateDB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateDBBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateDataDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // stateDBGridView
            // 
            this.stateDBGridView.AutoGenerateColumns = false;
            this.stateDBGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.stateDBGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stateIDDataGridViewTextBoxColumn,
            this.stateNameDataGridViewTextBoxColumn,
            this.populationDataGridViewTextBoxColumn,
            this.flagDescriptionDataGridViewTextBoxColumn,
            this.stateFlowerDataGridViewTextBoxColumn,
            this.stateBirdDataGridViewTextBoxColumn,
            this.colorsDataGridViewTextBoxColumn,
            this.largestCitiesDataGridViewTextBoxColumn,
            this.stateCapitalDataGridViewTextBoxColumn,
            this.medianIncomeDataGridViewTextBoxColumn,
            this.computerJobPercentageDataGridViewTextBoxColumn});
            this.stateDBGridView.DataSource = this.statesBindingSource;
            this.stateDBGridView.Location = new System.Drawing.Point(12, 12);
            this.stateDBGridView.Name = "stateDBGridView";
            this.stateDBGridView.Size = new System.Drawing.Size(1099, 150);
            this.stateDBGridView.TabIndex = 0;
            // 
            // stateIDDataGridViewTextBoxColumn
            // 
            this.stateIDDataGridViewTextBoxColumn.DataPropertyName = "StateID";
            this.stateIDDataGridViewTextBoxColumn.HeaderText = "StateID";
            this.stateIDDataGridViewTextBoxColumn.Name = "stateIDDataGridViewTextBoxColumn";
            this.stateIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // stateNameDataGridViewTextBoxColumn
            // 
            this.stateNameDataGridViewTextBoxColumn.DataPropertyName = "StateName";
            this.stateNameDataGridViewTextBoxColumn.HeaderText = "StateName";
            this.stateNameDataGridViewTextBoxColumn.Name = "stateNameDataGridViewTextBoxColumn";
            // 
            // populationDataGridViewTextBoxColumn
            // 
            this.populationDataGridViewTextBoxColumn.DataPropertyName = "Population";
            this.populationDataGridViewTextBoxColumn.HeaderText = "Population";
            this.populationDataGridViewTextBoxColumn.Name = "populationDataGridViewTextBoxColumn";
            // 
            // flagDescriptionDataGridViewTextBoxColumn
            // 
            this.flagDescriptionDataGridViewTextBoxColumn.DataPropertyName = "FlagDescription";
            this.flagDescriptionDataGridViewTextBoxColumn.HeaderText = "FlagDescription";
            this.flagDescriptionDataGridViewTextBoxColumn.Name = "flagDescriptionDataGridViewTextBoxColumn";
            // 
            // stateFlowerDataGridViewTextBoxColumn
            // 
            this.stateFlowerDataGridViewTextBoxColumn.DataPropertyName = "StateFlower";
            this.stateFlowerDataGridViewTextBoxColumn.HeaderText = "StateFlower";
            this.stateFlowerDataGridViewTextBoxColumn.Name = "stateFlowerDataGridViewTextBoxColumn";
            // 
            // stateBirdDataGridViewTextBoxColumn
            // 
            this.stateBirdDataGridViewTextBoxColumn.DataPropertyName = "StateBird";
            this.stateBirdDataGridViewTextBoxColumn.HeaderText = "StateBird";
            this.stateBirdDataGridViewTextBoxColumn.Name = "stateBirdDataGridViewTextBoxColumn";
            // 
            // colorsDataGridViewTextBoxColumn
            // 
            this.colorsDataGridViewTextBoxColumn.DataPropertyName = "Colors";
            this.colorsDataGridViewTextBoxColumn.HeaderText = "Colors";
            this.colorsDataGridViewTextBoxColumn.Name = "colorsDataGridViewTextBoxColumn";
            // 
            // largestCitiesDataGridViewTextBoxColumn
            // 
            this.largestCitiesDataGridViewTextBoxColumn.DataPropertyName = "LargestCities";
            this.largestCitiesDataGridViewTextBoxColumn.HeaderText = "LargestCities";
            this.largestCitiesDataGridViewTextBoxColumn.Name = "largestCitiesDataGridViewTextBoxColumn";
            // 
            // stateCapitalDataGridViewTextBoxColumn
            // 
            this.stateCapitalDataGridViewTextBoxColumn.DataPropertyName = "StateCapital";
            this.stateCapitalDataGridViewTextBoxColumn.HeaderText = "StateCapital";
            this.stateCapitalDataGridViewTextBoxColumn.Name = "stateCapitalDataGridViewTextBoxColumn";
            // 
            // medianIncomeDataGridViewTextBoxColumn
            // 
            this.medianIncomeDataGridViewTextBoxColumn.DataPropertyName = "MedianIncome";
            this.medianIncomeDataGridViewTextBoxColumn.HeaderText = "MedianIncome";
            this.medianIncomeDataGridViewTextBoxColumn.Name = "medianIncomeDataGridViewTextBoxColumn";
            // 
            // computerJobPercentageDataGridViewTextBoxColumn
            // 
            this.computerJobPercentageDataGridViewTextBoxColumn.DataPropertyName = "ComputerJobPercentage";
            this.computerJobPercentageDataGridViewTextBoxColumn.HeaderText = "ComputerJobPercentage";
            this.computerJobPercentageDataGridViewTextBoxColumn.Name = "computerJobPercentageDataGridViewTextBoxColumn";
            // 
            // statesBindingSource
            // 
            this.statesBindingSource.DataMember = "States";
            this.statesBindingSource.DataSource = this.stateDBDataSet;
            // 
            // stateDBDataSet
            // 
            this.stateDBDataSet.DataSetName = "StateDBDataSet";
            this.stateDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // stateDB
            // 
            this.stateDB.DataSetName = "StateDB";
            this.stateDB.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // stateDBBindingSource
            // 
            this.stateDBBindingSource.DataSource = this.stateDB;
            this.stateDBBindingSource.Position = 0;
            // 
            // statesTableAdapter
            // 
            this.statesTableAdapter.ClearBeforeFill = true;
            // 
            // comboBoxStates
            // 
            this.comboBoxStates.FormattingEnabled = true;
            this.comboBoxStates.Location = new System.Drawing.Point(420, 192);
            this.comboBoxStates.Name = "comboBoxStates";
            this.comboBoxStates.Size = new System.Drawing.Size(242, 21);
            this.comboBoxStates.TabIndex = 1;
            this.comboBoxStates.SelectedIndexChanged += new System.EventHandler(this.comboBoxStates_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(476, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Select a state";
            // 
            // seeInfoBtn
            // 
            this.seeInfoBtn.Location = new System.Drawing.Point(501, 219);
            this.seeInfoBtn.Name = "seeInfoBtn";
            this.seeInfoBtn.Size = new System.Drawing.Size(75, 23);
            this.seeInfoBtn.TabIndex = 3;
            this.seeInfoBtn.Text = "See info";
            this.seeInfoBtn.UseVisualStyleBackColor = true;
            this.seeInfoBtn.Click += new System.EventHandler(this.seeInfoBtn_Click);
            // 
            // stateDataDataSet1
            // 
            this.stateDataDataSet1.DataSetName = "StateDataDataSet";
            this.stateDataDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1229, 568);
            this.Controls.Add(this.seeInfoBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxStates);
            this.Controls.Add(this.stateDBGridView);
            this.Name = "Form1";
            this.Text = "State Database App";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stateDBGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateDB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateDBBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateDataDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView stateDBGridView;
        private StateDB stateDB;
        private System.Windows.Forms.BindingSource stateDBBindingSource;
        private StateDBDataSet stateDBDataSet;
        private System.Windows.Forms.BindingSource statesBindingSource;
        private StateDBDataSetTableAdapters.StatesTableAdapter statesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn stateIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stateNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn populationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flagDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stateFlowerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stateBirdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colorsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn largestCitiesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stateCapitalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn medianIncomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn computerJobPercentageDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox comboBoxStates;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button seeInfoBtn;
        private StateDataDataSet stateDataDataSet1;
    }
}

