﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NRoach_CPT_206_Lab_3
{
    public partial class StateDetailsForm : Form
    {
        public string StateName { get; set; }
        public string Population { get; set; }
        public string FlagDescription { get; set; }
        public string StateFlower { get; set; }
        public string StateBird { get; set; }
        public string Colors { get; set; }
        public string LargestCities { get; set; }
        public string StateCapital { get; set; }
        public string MedianIncome { get; set; }
        public string ComputerJobPercentage { get; set; }
        public StateDetailsForm()
        {
            InitializeComponent();
        }

        private void StateDetailsForm_Load(object sender, EventArgs e)
        {
            labelStateName.Text = StateName;
            labelPopulation.Text = Population;
            labelFlagDescription.Text = FlagDescription;
            labelStateFlower.Text = StateFlower;
            labelStateBird.Text = StateBird;
            labelColors.Text = Colors;
            labelLargestCities.Text = LargestCities;
            labelStateCapital.Text = StateCapital;
            labelMedianIncome.Text = MedianIncome;
            labelComputerJobPercentage.Text = ComputerJobPercentage;
        }
    }
}
