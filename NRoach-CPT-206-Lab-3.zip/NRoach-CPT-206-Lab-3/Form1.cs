﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NRoach_CPT_206_Lab_3
{
    public partial class Form1 : Form
    {
        string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\StateDB.mdf;Integrated Security=True;Connect Timeout=30";
        DataTable dataTable = new DataTable();

        public Form1()
        {
            InitializeComponent();
            LoadStatesData();
        }

        private void LoadStatesData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM States";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    stateDBGridView.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.statesTableAdapter.Fill(this.stateDBDataSet.States);
            comboBoxStates.Items.Clear();
            foreach (DataRow row in stateDBDataSet.States.Rows) // Add all the states to the combobox
            {
                comboBoxStates.Items.Add(row["StateName"].ToString());
            }
        }

        private void comboBoxStates_SelectedIndexChanged(object sender, EventArgs e)
        {
        }


        private void seeInfoBtn_Click(object sender, EventArgs e)
        {
            if (comboBoxStates.SelectedItem != null)
            {
                string selectedStateName = comboBoxStates.SelectedItem.ToString();

                // Find the selected state data
                DataRow selectedStateRow = dataTable.AsEnumerable().FirstOrDefault(row => row["StateName"].ToString() == selectedStateName);

                if (selectedStateRow != null)
                {
                    StateDetailsForm detailsForm = new StateDetailsForm();

                    // Pass the selected state's data to the new form
                    detailsForm.StateName = selectedStateRow["StateName"].ToString();
                    detailsForm.Population = selectedStateRow["Population"].ToString();
                    detailsForm.FlagDescription = selectedStateRow["FlagDescription"].ToString();
                    detailsForm.StateFlower = selectedStateRow["StateFlower"].ToString();
                    detailsForm.StateBird = selectedStateRow["StateBird"].ToString();
                    detailsForm.Colors = selectedStateRow["Colors"].ToString();
                    detailsForm.LargestCities = selectedStateRow["LargestCities"].ToString();
                    detailsForm.StateCapital = selectedStateRow["StateCapital"].ToString();
                    detailsForm.MedianIncome = selectedStateRow["MedianIncome"].ToString();
                    detailsForm.ComputerJobPercentage = selectedStateRow["ComputerJobPercentage"].ToString();

                    // Show the details form
                    detailsForm.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Select a state.");
            }
        }
    }
}
