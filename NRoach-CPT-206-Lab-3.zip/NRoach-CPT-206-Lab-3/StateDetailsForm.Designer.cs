﻿namespace NRoach_CPT_206_Lab_3
{
    partial class StateDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelStateName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelPopulation = new System.Windows.Forms.Label();
            this.labelFlagDescription = new System.Windows.Forms.Label();
            this.labelStateFlower = new System.Windows.Forms.Label();
            this.labelStateBird = new System.Windows.Forms.Label();
            this.labelColors = new System.Windows.Forms.Label();
            this.labelLargestCities = new System.Windows.Forms.Label();
            this.labelStateCapital = new System.Windows.Forms.Label();
            this.labelMedianIncome = new System.Windows.Forms.Label();
            this.labelComputerJobPercentage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelStateName
            // 
            this.labelStateName.AutoSize = true;
            this.labelStateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStateName.Location = new System.Drawing.Point(182, 9);
            this.labelStateName.Name = "labelStateName";
            this.labelStateName.Size = new System.Drawing.Size(117, 24);
            this.labelStateName.TabIndex = 0;
            this.labelStateName.Text = "State Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(157, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Population";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(106, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Flag Description";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(142, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "State Flower";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(167, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "State Bird";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(196, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "Colors";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(131, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 24);
            this.label6.TabIndex = 6;
            this.label6.Text = "Largest Cities";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(141, 289);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 24);
            this.label7.TabIndex = 7;
            this.label7.Text = "State Capital";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(114, 324);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(154, 24);
            this.label8.TabIndex = 8;
            this.label8.Text = "Median Income";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 357);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(254, 24);
            this.label9.TabIndex = 9;
            this.label9.Text = "Computer Job Percentage";
            // 
            // labelPopulation
            // 
            this.labelPopulation.AutoSize = true;
            this.labelPopulation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPopulation.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelPopulation.Location = new System.Drawing.Point(272, 73);
            this.labelPopulation.Name = "labelPopulation";
            this.labelPopulation.Size = new System.Drawing.Size(77, 24);
            this.labelPopulation.TabIndex = 10;
            this.labelPopulation.Text = "label10";
            // 
            // labelFlagDescription
            // 
            this.labelFlagDescription.AutoSize = true;
            this.labelFlagDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFlagDescription.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelFlagDescription.Location = new System.Drawing.Point(272, 107);
            this.labelFlagDescription.Name = "labelFlagDescription";
            this.labelFlagDescription.Size = new System.Drawing.Size(77, 24);
            this.labelFlagDescription.TabIndex = 11;
            this.labelFlagDescription.Text = "label11";
            // 
            // labelStateFlower
            // 
            this.labelStateFlower.AutoSize = true;
            this.labelStateFlower.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStateFlower.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelStateFlower.Location = new System.Drawing.Point(274, 142);
            this.labelStateFlower.Name = "labelStateFlower";
            this.labelStateFlower.Size = new System.Drawing.Size(77, 24);
            this.labelStateFlower.TabIndex = 12;
            this.labelStateFlower.Text = "label12";
            // 
            // labelStateBird
            // 
            this.labelStateBird.AutoSize = true;
            this.labelStateBird.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStateBird.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelStateBird.Location = new System.Drawing.Point(272, 175);
            this.labelStateBird.Name = "labelStateBird";
            this.labelStateBird.Size = new System.Drawing.Size(77, 24);
            this.labelStateBird.TabIndex = 13;
            this.labelStateBird.Text = "label13";
            // 
            // labelColors
            // 
            this.labelColors.AutoSize = true;
            this.labelColors.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelColors.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelColors.Location = new System.Drawing.Point(272, 211);
            this.labelColors.Name = "labelColors";
            this.labelColors.Size = new System.Drawing.Size(77, 24);
            this.labelColors.TabIndex = 14;
            this.labelColors.Text = "label14";
            // 
            // labelLargestCities
            // 
            this.labelLargestCities.AutoSize = true;
            this.labelLargestCities.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLargestCities.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelLargestCities.Location = new System.Drawing.Point(272, 248);
            this.labelLargestCities.Name = "labelLargestCities";
            this.labelLargestCities.Size = new System.Drawing.Size(77, 24);
            this.labelLargestCities.TabIndex = 15;
            this.labelLargestCities.Text = "label15";
            // 
            // labelStateCapital
            // 
            this.labelStateCapital.AutoSize = true;
            this.labelStateCapital.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStateCapital.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelStateCapital.Location = new System.Drawing.Point(272, 289);
            this.labelStateCapital.Name = "labelStateCapital";
            this.labelStateCapital.Size = new System.Drawing.Size(77, 24);
            this.labelStateCapital.TabIndex = 16;
            this.labelStateCapital.Text = "label16";
            // 
            // labelMedianIncome
            // 
            this.labelMedianIncome.AutoSize = true;
            this.labelMedianIncome.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMedianIncome.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelMedianIncome.Location = new System.Drawing.Point(272, 324);
            this.labelMedianIncome.Name = "labelMedianIncome";
            this.labelMedianIncome.Size = new System.Drawing.Size(77, 24);
            this.labelMedianIncome.TabIndex = 17;
            this.labelMedianIncome.Text = "label17";
            // 
            // labelComputerJobPercentage
            // 
            this.labelComputerJobPercentage.AutoSize = true;
            this.labelComputerJobPercentage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelComputerJobPercentage.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelComputerJobPercentage.Location = new System.Drawing.Point(272, 357);
            this.labelComputerJobPercentage.Name = "labelComputerJobPercentage";
            this.labelComputerJobPercentage.Size = new System.Drawing.Size(77, 24);
            this.labelComputerJobPercentage.TabIndex = 18;
            this.labelComputerJobPercentage.Text = "label18";
            // 
            // StateDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 450);
            this.Controls.Add(this.labelComputerJobPercentage);
            this.Controls.Add(this.labelMedianIncome);
            this.Controls.Add(this.labelStateCapital);
            this.Controls.Add(this.labelLargestCities);
            this.Controls.Add(this.labelColors);
            this.Controls.Add(this.labelStateBird);
            this.Controls.Add(this.labelStateFlower);
            this.Controls.Add(this.labelFlagDescription);
            this.Controls.Add(this.labelPopulation);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelStateName);
            this.Name = "StateDetailsForm";
            this.Text = "StateDetailsForm";
            this.Load += new System.EventHandler(this.StateDetailsForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelStateName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelPopulation;
        private System.Windows.Forms.Label labelFlagDescription;
        private System.Windows.Forms.Label labelStateFlower;
        private System.Windows.Forms.Label labelStateBird;
        private System.Windows.Forms.Label labelColors;
        private System.Windows.Forms.Label labelLargestCities;
        private System.Windows.Forms.Label labelStateCapital;
        private System.Windows.Forms.Label labelMedianIncome;
        private System.Windows.Forms.Label labelComputerJobPercentage;
    }
}